#!/usr/bin/env bash
#
# escanear_aula.sh
# -----------------------------------------------------------------
# Alternativa al inventario dinámico de la colección community.general
# (por si "ansible-galaxy collection install community.general" da
# problemas de pre-release/dependencias, como ha pasado).
#
# Hace un ping-sweep con nmap sobre la subred del aula, arma con las
# IPs vivas un inventario "en línea" (sin fichero, separado por
# comas) y lanza directamente el playbook de bootstrap contra él.
# No necesita ninguna colección de Ansible adicional.
#
# Uso:
#   ./escanear_aula.sh 10.0.16.0/24
#   ./escanear_aula.sh 10.0.16.0/24 --ask-become-pass
#
# IMPORTANTE: NO lances este script con "sudo ./escanear_aula.sh".
# Solo el escaneo ARP necesita privilegios (por eso internamente se
# hace "sudo nmap ..."), pero ansible-playbook debe ejecutarse como
# TU usuario normal: si lo lanzas todo con sudo, ansible-playbook
# pasa a correr como root, y root no tiene tu clave SSH (está en tu
# $HOME, no en /root), así que la autenticación por clave fallaría.
# Cuando llegue al "sudo nmap" te pedirá la contraseña si hace falta.
# -----------------------------------------------------------------
set -euo pipefail

if [[ $EUID -eq 0 ]]; then
    echo "No lances este script con sudo (rompe la autenticación SSH por clave)." >&2
    echo "Ejecuta: ./escanear_aula.sh <subred/prefijo>   (te pedirá sudo solo para el escaneo nmap)" >&2
    exit 1
fi

SUBRED="${1:?Uso: $0 <subred/prefijo>  (ej: 10.0.16.0/24)}"
shift || true

command -v nmap >/dev/null 2>&1 || { echo "Falta nmap. Instálalo con: sudo apt install nmap" >&2; exit 1; }
command -v ansible-playbook >/dev/null 2>&1 || { echo "Falta ansible-playbook." >&2; exit 1; }

echo "Escaneando $SUBRED (puede pedirte la contraseña de sudo, solo para el escaneo)..."
HOSTS="$(sudo nmap -sn "$SUBRED" -oG - | awk '/Up$/{print $2}' | paste -sd,)"

if [[ -z "$HOSTS" ]]; then
    echo "No se ha detectado ningún equipo activo en $SUBRED." >&2
    exit 1
fi

echo "Equipos detectados:"
echo "$HOSTS" | tr ',' '\n' | sed 's/^/  - /'
echo

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# el "," final es obligatorio: le dice a Ansible que es una lista
# de hosts en línea, no la ruta a un fichero de inventario.
# ansible-playbook se ejecuta como tu usuario normal (no root), así
# que usa tu propia clave SSH / agente tal cual los tienes configurados.
ansible-playbook -i "${HOSTS}," "$SCRIPT_DIR/bootstrap_equipos.yml" "$@"
